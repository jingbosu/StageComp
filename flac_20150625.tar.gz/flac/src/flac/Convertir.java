package flac;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Convertir {

	protected int intervalleMin;
	protected int intervalleMax;
	protected int min=0;
	protected int max=0;
	protected int a=0;
	protected int b=0;
	protected int filesize;
	
	public Convertir(int intervalleMin, int intervalleMax){
		this.intervalleMin=intervalleMin;
		this.intervalleMax=intervalleMax;
	}
	
	public void tailleFichier(String nom){
		File f=new File(nom);
		this.filesize=(int) (f.length()/4);
		System.out.println("filesize = "+filesize);
	}
	
	public int[] lireFichier(String nom) throws IOException{
		File f = new File(nom);
		DataInputStream in = new DataInputStream(new FileInputStream(f));
		int length = 0;
		int tabInt[] = new int[this.filesize];
		
		for (int j = 0;j<this.filesize;j++){
			byte data[] = new byte[100];
			in.read(data, length, 4);			
			int buffer = (int)ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN).getInt();
			System.out.println("buffer = "+buffer);
			tabInt[j]=buffer;
		}
		in.close();
		return tabInt;
	}
	
	public void chercheMinMax(int[] tab){
		min=tab[0];
		max=tab[0];
		for (int i : tab){
			if (tab[i]<min){
				min=tab[i];
			}else if (tab[i]>max){
				max=tab[i];
			}
		}
		System.out.println("Min = "+min);
		System.out.println("Max = "+max);
	}
	
	public void calculeCoeff(){
		this.a = (this.intervalleMax-this.intervalleMin)/(this.max-this.min);
		this.b = (int)(this.intervalleMax-this.max*this.a);
	}
	
	public int[] ecritBuff(int[] tab){
		int[] intTab=new int[filesize];
		for (int i=0; i<filesize;i++){
			intTab[i]=a*tab[i]+b;
		}
		return intTab;	
	}
}
