package flac;

import java.io.IOException;

public class TestConvertir {

	public static void main(String[] args) throws IOException {
		String nom="/home/su/Bureau/flac/src/toto_bis.bin";
		Convertir c = new Convertir(-32768, 32767);
		c.tailleFichier(nom);
		int[] tab = c.lireFichier(nom);
		c.chercheMinMax(tab);
		c.calculeCoeff();
		int[] tab1=c.ecritBuff(tab);
		for(int i=0;i<c.filesize;i++){
			System.out.println("Le nombre de tab1["+i+"] est : "+tab1[i]);
		}
	}

}
